<!DOCTYPE html>
<html lang="es">
    <head>
        <title>
            <?php echo $__env->yieldContent('title'); ?> | DIGED
        </title>
        <meta charset="utf-8">
            <meta content="width=device-width, initial-scale=1, shrink-to-fit=no" name="viewport">
                <link href="<?php echo e(asset('Plugins/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
                    <?php echo $__env->yieldContent('customs'); ?>
                </link>
            </meta>
        </meta>
    </head>
    <body class="bg-light">
        
        <?php echo $__env->yieldContent('content'); ?>

    <footer>
        <hr class="mb-4" />

    </footer>
    </body >

        <script src="<?php echo e(asset('Plugins/bootstrap/jquery/jquery.min.js')); ?>">
        </script>
        <script src="<?php echo e(asset('Plugins/bootstrap/js/popper.min.js')); ?>">
        </script>
        <script src="<?php echo e(asset('Plugins/bootstrap/js/bootstrap.min.js')); ?>">
        </script>
               
        <?php echo $__env->yieldContent('scripts'); ?>
    
</html><?php /**PATH C:\Users\usuario\Desktop\appDIGED\resources\views/commons/maintemplate.blade.php ENDPATH**/ ?>