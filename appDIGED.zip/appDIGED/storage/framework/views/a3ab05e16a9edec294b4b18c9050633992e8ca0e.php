<!DOCTYPE html>
<html lang="es">
    <head>
        <title>
            <?php echo $__env->yieldContent('title'); ?> | DIGED
        </title>
        <meta charset="utf-8">
            <meta content="width=device-width, initial-scale=1, shrink-to-fit=no" name="viewport">
                <link href="<?php echo e(asset('Plugins/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
                    <?php echo $__env->yieldContent('customs'); ?>
                </link>
            </meta>
        </meta>
    </head>
</html>
<body class="bg-light">
    <?php echo $__env->yieldContent('content'); ?>
</body>
<footer>
    <script src="<?php echo e(asset('Plugins/bootstrap/jquery/jquery.slim.min.js')); ?>">
    </script>
    <script src="<?php echo e(asset('Plugins/bootstrap/js/popper.min.js')); ?>">
    </script>
    <script src="<?php echo e(asset('Plugins/bootstrap/js/bootstrap.min.js')); ?>">
    </script>
</footer>
<?php /**PATH C:\xampp\htdocs\appDIGED\resources\views/commons/maintemplate.blade.php ENDPATH**/ ?>