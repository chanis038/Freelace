<?php switch($request->tipo):
        case ("PM"): ?>
        Pago de Maestría
         <?php break; ?>
        <?php case ('PD'): ?>
        Pago de Doctorado
         <?php break; ?>
        <?php case ('PB'): ?>
        Pago de Boleto Aéreo
         <?php break; ?>
        <?php case ('PV'): ?>
        Pago de Viáticos
         <?php break; ?>                         
        <?php default: ?>
        Pago de Boleto Aéreo y Viáticos
        <?php break; ?>
                        
<?php endswitch; ?>
<?php /**PATH C:\Users\usuario\Documents\GitHub\Freelace\appDIGED\resources\views/validates/tiposolicitud.blade.php ENDPATH**/ ?>