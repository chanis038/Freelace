<script type="">

function redireccionar(){
 window.location="/viewRequestM/<?php echo e($data[0]->slug); ?>";
}

if( /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) ) {
   
	redireccionar();
}
</script>


<?php $__env->startSection('filescontent'); ?>

 	<div class="my-3 p-3 bg-white rounded shadow-sm">
    <div id="carousel" class="carousel slide carousel-fade" data-ride="carousel"  data-interval="false">
  <div class="carousel-inner">

  	 <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  	 <?php if($loop->first): ?>
     <div class="carousel-item active">
     <?php else: ?>
     <div class="carousel-item ">
     <?php endif; ?>
    <div class="embed-responsive embed-responsive-16by9 bg-dark" >
     
      <?php if($file->tipoA ==".pdf"): ?>
  	<object data="<?php echo e('/Solicitudes/'.$file->ruta.$file->nombre.$file->tipoA); ?>" type="application/pdf">
        <embed src="<?php echo e('/Solicitudes/'.$file->ruta.$file->nombre.$file->tipoA); ?>"
          />
    </object>
    <?php else: ?>
       
      <object data="<?php echo e('/Solicitudes/'.$file->ruta.$file->nombre.$file->tipoA); ?>" type="application/image">
        <embed class="img-fluid" max-width="100%" height="auto" src="<?php echo e('/Solicitudes/'.$file->ruta.$file->nombre.$file->tipoA); ?>"
          />
    </object>
         
    <?php endif; ?>
	</div>


	</div>

	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
  </div>
  <a class="carousel-control-prev" href="#carousel" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Anterior</span>
  </a>
  <a class="carousel-control-next" href="#carousel" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Siguiente</span>
  </a>

</div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('link'); ?>
    <a class="list-group-item-warning " href="/viewRequestM/<?php echo e($data[0]->slug); ?>">
                       Clic aqui,si no puede ver los archivos.!!
                    </a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('commons.viewrequesttemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\usuario\Documents\GitHub\Freelace\appDIGED\resources\views/dashboard/viewrquest.blade.php ENDPATH**/ ?>