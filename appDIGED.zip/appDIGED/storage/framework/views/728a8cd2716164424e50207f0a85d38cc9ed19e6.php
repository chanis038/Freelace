<?php switch($request->estado):
	case ('EN'): ?>
		Enviado a Revision
		<?php break; ?>

	<?php case ('AP'): ?>
		Revision Aprobada
		<?php break; ?>

	<?php case ('AT'): ?>
	    Autorizado
		<?php break; ?>

	<?php case ('ET'): ?>
	    Enviado a Tesoreria
		<?php break; ?>
		
	<?php case ('LT'): ?>
	    Listo para recoger
		<?php break; ?>

	<?php case ('NA'): ?>
	    Listo
		<?php break; ?>

	<?php case ('AA'): ?>
	    Autorizado
		<?php break; ?>
	                        	
	<?php default: ?>
		Entregado
		<?php break; ?>
<?php endswitch; ?><?php /**PATH C:\Users\usuario\Documents\GitHub\Freelace\appDIGED\resources\views/validates/estadosolicitud.blade.php ENDPATH**/ ?>