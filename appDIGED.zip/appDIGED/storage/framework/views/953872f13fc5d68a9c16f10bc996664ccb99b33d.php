<?php $__env->startSection('title'); ?>
Historial
<?php $__env->stopSection(); ?>

<?php $__env->startSection('inhistory'); ?>
active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contentDash'); ?>

<main class="container mt-3" id="dashmain" >
	<form action="<?php echo e(route('history')); ?>" method="GET">
		<?php echo e(csrf_field()); ?>

	<div class="input-group input-group-sm mb-4 ">

	<?php if(auth()->user()->perfil !="U"): ?>
  	 <input type="text" class="form-control mr-sm-2 rounded"  placeholder="Registro" name="registro" pattern="[0-9]{7,11}" title="El campo solo permite numeros, sin espacios" >
  	 <input type="text" class="form-control mr-sm-2 rounded"  placeholder="nombre" name="nombre" pattern="[a-zA-ZáíóöúüñÁÉÍÓÚÜÑ]{2,60}" title="El campo solo permite letras " >
  	<?php endif; ?>
  	 <input type="number" class="form-control mr-sm-2 rounded"  placeholder="Mes" max="12" name='mes'>
  	 <input type="number" class="form-control mr-sm-2 rounded"  placeholder="Año"  min="2010" name="anio">
  	 <span class="d-inline-block"  data-toggle="tooltip" title="Buscar">
  	 <button type="summit" class="btn btn-primary fas fa-search"> </button>
  	</span>
	</div>
	</form>

	<table class="table table-sm ">
  	<thead  >
    <tr  class="my-3 p-3 text-white-50 bg-purple shadow-sm rounded ">
      <th  scope="col">Id</th>
      <th scope="col">Solicitante</th>
      <th scope="col">Que solicita</th>
      <th scope="col">Estado</th>
      <?php if($data): ?>
      <?php if(auth()->user()->perfil!="U"): ?>
       <th scope="col">Observación</th>
      <?php endif; ?>
      <?php endif; ?>

      <th scope="col">Ver</th>
    </tr>
  </thead>

  <tbody>

      <?php if($data): ?>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 	<tr>
	<th scope="row">SAE-<?php echo e($request->id); ?></th>
      <td>
      	 <div class="media-body pb-3 mb-0 small  border-gray">
        <span class="d-block">Numero de registro: <?php echo e($request->registro); ?></span>    
        <span class="d-block">Nombre: <?php echo e($request->p_nombre.' '.$request->p_apellido); ?></span>
        <span class="d-block">Unidad Academica: <?php echo e($request->unidad_academica); ?></span>
        <span class="d-block">Titularidad: <?php echo e($request->titularidad); ?></span>
                         
           </div>
      </td>
      <td>
      	 <div class="media-body pb-3 mb-0 small   border-gray">
	    <span class="d-block">Justificación: <?php echo e($request->justificacion); ?></span>    
	    <span class="d-block">Monto: <?php echo e($request->monto); ?></span></td>
      </div>
      <td>
      	 <div class="media-body pb-3 mb-0 small  border-gray">
      <?php echo $__env->make("validates/estadosolicitud", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </div>
  	</td>
 	<?php if(auth()->user()->perfil!="U"): ?>
  	<td>
      	 <div class="media-body pb-3 mb-0 small  border-gray">
      <span class="d-block"><?php echo e($request->observacion); ?></span>
  </div>
  	</td>
  	<?php endif; ?>
      <td>
  			 <?php if($request->estado =="EN" && auth()->user()->perfil=="U"): ?>
              <a class="badge badge-info" href="/viewModifyRequest/<?php echo e($request->slug); ?>">
              <span class="d-inline-block"  data-toggle="tooltip" title="Editar">
              <i class="fas fa-edit"></i> </span></a>

              <?php endif; ?>
                
                <a  class="badge badge-info" href="/viewRequest/<?php echo e($request->slug); ?>">
                <span class="d-inline-block"  data-toggle="tooltip" title="Ver Solicitud">
                <i class="fas fa-eye"></i>
                </span>
                </a>

               
      </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
  </tbody>
    <?php endif; ?>
</table>
   <?php if($data): ?>
   	<?php echo e($data->render()); ?>

   	<?php endif; ?>


</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('commons.dashboardtemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\usuario\Documents\GitHub\Freelace\appDIGED\resources\views/dashboard/history.blade.php ENDPATH**/ ?>