 <?php if(session('result')): ?>
       <?php if(session('result')=="succes"): ?>
          <div class="alert alert-primary alert-dismissible fade show"  role="alert">
               Solcitud Creada Con exito..!!!
              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>            
      
          <?php else: ?>
            
            <div class="alert alert-warning alert-dismissible fade show "  role="alert">
                   Error al tratar de crear solicitud.. vuelve a intentarlo.. !!!
                  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
        
          <?php endif; ?>
              <?php endif; ?><?php /**PATH C:\Users\usuario\Desktop\appDIGED\resources\views/validates/validatescreaterequest.blade.php ENDPATH**/ ?>