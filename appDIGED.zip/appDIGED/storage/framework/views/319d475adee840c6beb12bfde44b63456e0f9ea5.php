<?php $__env->startSection('title'); ?>
Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('indashboard'); ?>
active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contentDash'); ?>

<main class="container" id="dashmain" role="main">
  <?php echo $__env->make('validates/validatescreaterequest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	 <div class="d-flex align-items-center p-3 my-3 text-white-50 bg-purple rounded shadow-sm">
        <div class="lh-100">
            <h6 class="mb-0 text-white lh-100">
              Lista de Solicitudes

            </h6>
                    </div>
    </div>

    <div class="my-3 p-3 bg-white rounded shadow-sm">
        <h6 class="border-bottom border-gray pb-2 mb-0">Ultimas Solicitudes</h6>
     
      <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="media text-muted pt-3">
          <h8 class="mr-2 rounded"> SAE-<?php echo e($request->id); ?></h8>
          <div class="media-body pb-3 mb-0 small lh-125 border-bottom border-gray">
            <div class="d-flex justify-content-between align-items-center w-100">
              <strong class="text-gray-dark">
              	         <?php switch($request->tipo):
                        	 case ("PM"): ?>
                        		Pago de Maestría
                        		 <?php break; ?>
                        	 <?php case ('PD'): ?>
                        		Pago de Doctorado
                        		 <?php break; ?>
                        	 <?php case ('PB'): ?>
                        	  	Pago de Boleto Aéreo
                        		 <?php break; ?>
                        	 <?php case ('PV'): ?>
                        		Pago de Viáticos
                        		 <?php break; ?>                       	
                        	 <?php default: ?>
                        		Pago de Boleto Aéreo y Viáticos
                        		<?php break; ?>
                        
                        <?php endswitch; ?>

              </strong>
              <a href="/viewRequest/<?php echo e($request->slug); ?>">Ver Solicitud</a>
            </div>
            <span class="d-block">Fecha de Creacion: <?php echo e($request->created_at); ?></span>
            <span class="d-block">Estado: <?php switch($request->estado):
                        	case ('E'): ?>
                        		Enviado a Revision
                        		<?php break; ?>
                        	<?php case ('A'): ?>
                        		Revision Aprobada
                        		
                        		<?php break; ?>
                        	<?php case ('AT'): ?>
                        	    Autorizado

                        		<?php break; ?>
                        	                        	
                        	<?php default: ?>
                        		Listo en Tesoreria
                        		<?php break; ?>
                        <?php endswitch; ?></span>
                     </div>
                 </div>

  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	 

             
      </div>
     
 </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('commons.dashboardtemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\usuario\Desktop\appDIGED\resources\views/dashboard/dashboard.blade.php ENDPATH**/ ?>