<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<p> <?php echo $content; ?></p>
</body>
</html><?php /**PATH C:\Users\usuario\Documents\GitHub\Freelace\appDIGED\resources\views/mails/sendmail.blade.php ENDPATH**/ ?>