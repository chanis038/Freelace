<?php $__env->startSection('customs'); ?>
<link href="<?php echo e(asset('Plugins/css/dashboard.css')); ?>" type="text/css" rel="stylesheet">
</link>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Content here -->
    <header>
    <nav class="navbar navbar-expand-lg navbar-light   fixed-top">
        <a class="navbar-brand" href="/dashboard">
            <img alt="DIGED" id="iconn" src="/images/diged.png"/>
            DIGED
        </a>
        <button aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation" class="navbar-toggler" data-target="#navbarSupportedContent" data-toggle="collapse" type="button">
            <span class="navbar-toggler-icon">
            </span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item <?php echo $__env->yieldContent('indashboard'); ?>">
                    <a class="nav-link" href="\dashboard">
                        Dashboard
                    </a>
                </li>
                <li class="nav-item <?php echo $__env->yieldContent('inpersonalinf'); ?>">
                    <a class="nav-link" href="\personalinf">
                        Informacion Personal
                    </a>
                </li>
                <?php if( auth()->user()->perfil =='U'): ?>
                <li class="nav-item <?php echo $__env->yieldContent('increate'); ?>">
                    <a class="nav-link" href="\createR">
                        Crear Solicitud
                    </a>
                </li>
                <?php elseif(auth()->user()->perfil =='R'): ?>
                <li class="nav-item <?php echo $__env->yieldContent('inconfigure'); ?>">
                    <a class="nav-link" href="\configure">
                        Configuraciones
                    </a>
                </li>
                <?php endif; ?>
                <li class="nav-item <?php echo $__env->yieldContent('inhistory'); ?>">
                    <a class="nav-link " href="\history">
                        Historial
                    </a>
                </li>
                <?php echo $__env->yieldContent('inview'); ?>
            </ul>
            
            <form action="<?php echo e(route('logout')); ?>" class="form-inline my-2 my-lg-0" method="POST">
                <?php echo e(csrf_field()); ?>

                <ul class="navbar-nav mr-auto">
                    <li class="nav-item Active">
                        <h6 class="nav-link" >
                                   
                            Usuario: <?php echo e(auth()->user()->p_nombre); ?>

                         </h6>
                    </li>
                    <li class="nav-item">
                        <button class="btn btn-outline-success my-2 my-sm-0" type="submit">
                            logout
                        </button>
                    </li>
                </ul>
            </form>
        </div>
    </nav>
 <header>
  <section>      
    <?php echo $__env->yieldContent('contentDash'); ?>
   </section>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('commons.maintemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\usuario\Desktop\appDIGED\resources\views/commons/dashboardtemplate.blade.php ENDPATH**/ ?>