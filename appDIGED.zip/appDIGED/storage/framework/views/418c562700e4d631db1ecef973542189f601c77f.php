
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<p>
		<strong><?php echo e($introduction); ?>:</strong>	
	</p>
	<p>
	<strong>Docente: </strong><?php echo e(' '.$owner[0]->p_nombre.' '.$owner[0]->p_apellido); ?>

	 
	<br><strong>Tipo: </strong>.
				<?php
				 $request = $solicitud;

				?>
				<?php echo $__env->make('validates.tiposolicitud', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<br><strong>Justificacion:  </strong><?php echo e($solicitud->justificacion); ?>


	<br><strong>Id Solicitud: </strong>SAE- <?php echo e($solicitud->id); ?>

	</p>
    <br>
    <br>
    <br>
	<footer>
		<strong>DIGED</strong><br>
		mensaje automantico, por favor no lo responda...
	</footer>
</body>
</html>







<?php /**PATH C:\Users\usuario\Documents\GitHub\Freelace\appDIGED\resources\views/mails/sendemial.blade.php ENDPATH**/ ?>